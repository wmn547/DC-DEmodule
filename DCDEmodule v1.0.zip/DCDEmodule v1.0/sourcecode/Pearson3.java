package dcde;

import java.util.ArrayList;
import java.util.List;

public class Pearson3 {
	public List<Double> pearson3(String[][] Module, int sample1, int sample2) {
		List<Double> DS = new ArrayList<Double>();
		int nc=Module.length;
		/*****************************************************************************/
		for(int m=0;m<nc;m++){
			for(int n=m+1;n<nc;n++){
		double corNT=0;
		
		
		
		double numNT11=0;
		double sumNT11=0;
		double meanNT11=0;
		double numNT21=0;
		double sumNT21=0;
		double meanNT21=0;
		double lNT11=0;
		double lNT21=0;
		double lNT31=0;
		
		
		
		for(int r=0;r<sample1;r++){
			if(Module[m][r] != null && Module[m][r].length() > 0){
			numNT11++;
			sumNT11=sumNT11+Double.parseDouble(Module[m][r]);
			}
			if(Module[n][r] != null && Module[n][r].length() > 0){
				numNT21++;
				sumNT21=sumNT21+Double.parseDouble(Module[n][r]);
				}
		}
		meanNT11=sumNT11/numNT11;
		meanNT21=sumNT21/numNT21;
		for(int r=0;r<sample1;r++){
			if(Module[m][r] != null && Module[m][r].length() > 0 && Module[n][r] != null && Module[n][r].length() > 0){
			lNT11=lNT11+(Double.parseDouble(Module[m][r])-meanNT11)*(Double.parseDouble(Module[n][r])-meanNT21);
			lNT21=lNT21+(Double.parseDouble(Module[m][r])-meanNT11)*(Double.parseDouble(Module[m][r])-meanNT11);
			lNT31=lNT31+(Double.parseDouble(Module[n][r])-meanNT21)*(Double.parseDouble(Module[n][r])-meanNT21);
			}
		}
		corNT=Math.abs(lNT11/Math.sqrt(lNT21*lNT31));
		DS.add(corNT);
		
		
			}
		}
		for(int m=0;m<nc;m++){
			for(int n=m+1;n<nc;n++){
		/*****************************************************************************/
				double corT=0;
		double numT11=0;
		double sumT11=0;
		double meanT11=0;
		double numT21=0;
		double sumT21=0;
		double meanT21=0;
		double lT11=0;
		double lT21=0;
		double lT31=0;
		
		
		
		for(int r=sample1;r<sample1+sample2;r++){
			if(Module[m][r] != null && Module[m][r].length() > 0){
			numT11++;
			sumT11=sumT11+Double.parseDouble(Module[m][r]);
			}
			if(Module[n][r] != null && Module[n][r].length() > 0){
				numT21++;
				sumT21=sumT21+Double.parseDouble(Module[n][r]);
				}
		}
		meanT11=sumT11/numT11;
		meanT21=sumT21/numT21;
		for(int r=sample1;r<sample1+sample2;r++){
			if(Module[m][r] != null && Module[m][r].length() > 0 && Module[n][r] != null && Module[n][r].length() > 0){
			lT11=lT11+(Double.parseDouble(Module[m][r])-meanT11)*(Double.parseDouble(Module[n][r])-meanT21);
			lT21=lT21+(Double.parseDouble(Module[m][r])-meanT11)*(Double.parseDouble(Module[m][r])-meanT11);
			lT31=lT31+(Double.parseDouble(Module[n][r])-meanT21)*(Double.parseDouble(Module[n][r])-meanT21);
			}
		}
		corT=Math.abs(lT11/Math.sqrt(lT21*lT31));
		DS.add(corT);
			}
		}
		
		/*****************************************************************************/
		
		return DS;
	}

}
