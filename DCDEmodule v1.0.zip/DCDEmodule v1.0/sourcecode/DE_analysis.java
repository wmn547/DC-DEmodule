package dcde;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;





public class DE_analysis {
	private BufferedWriter outXml2;
	public static void main(String[] args) {
		new DE_analysis();	
	}
	public DE_analysis(){
		List<String> gene = new ArrayList<String>();
		List<String> list = new ArrayList<String>();
		List<String> pvalue = new ArrayList<String>();
		List<String> ranpvalue = new ArrayList<String>();
		List<String> color = new ArrayList<String>();
		List<String> module = new ArrayList<String>();
		try {
			
			BufferedReader bufferedReader1 = new BufferedReader(new FileReader("DE_analysis_sample/Gene_DE_pvalue.txt"));
			BufferedReader bufferedReader2 = new BufferedReader(new FileReader("DE_analysis_sample/Module_file.txt"));
			String lineTxt = null;
			/**********************************************************/
			int count = 0;
			while((lineTxt = bufferedReader1.readLine()) != null){
				if(count != 0){
					list.add(Arrays.asList(lineTxt.split("\\t")).get(0));
					 pvalue.add(Arrays.asList(lineTxt.split("\\t")).get(1));
					 ranpvalue.add(Arrays.asList(lineTxt.split("\\t")).get(1));
				}
				 count++;
        }
        bufferedReader1.close();
           /**********************************************************/
        HashSet<String> mol = new HashSet<String>();
        count=0;
        while((lineTxt = bufferedReader2.readLine()) != null){
        	if(count != 0){
        		gene.add(Arrays.asList(lineTxt.split("\\t")).get(0));
            	color.add(Arrays.asList(lineTxt.split("\\t")).get(1));
            	mol.add(Arrays.asList(lineTxt.split("\\t")).get(1));
        	}
        	count++;
        }
        
        Iterator<String> iterator=mol.iterator();
    	while(iterator.hasNext()){
			module.add(iterator.next());
		}
        
        bufferedReader2.close();
		}catch (Exception e) {
	        System.out.println("��ȡ�ļ����ݳ���");
	        e.printStackTrace();
	    }
		
		
		String gsea[][] = new String[module.size()][2];
		for(int mol=0;mol<module.size();mol++){
			gsea[mol][0]=module.get(mol);
			double S=0;
			List<String> set = new ArrayList<String>();
			List<Integer> loc = new ArrayList<Integer>();
			for(int j=0;j<gene.size();j++){
				if(color.get(j).equals(module.get(mol))){
					set.add(gene.get(j));
				}
				}
			for(int i=0;i<set.size();i++){
				for(int j=0;j<list.size();j++){
					if(set.get(i).equals(list.get(j))){
						loc.add(j);
					}
				}
			}
			for(int i=0;i<set.size();i++){
				S=S+Math.abs(Double.parseDouble(pvalue.get(loc.get(i)))-0.5)*Math.abs(Double.parseDouble(pvalue.get(loc.get(i)))-0.5)/set.size();
				//S=S+Math.abs(Double.parseDouble(pvalue.get(loc.get(i)))-0.5)/set.size();
			}
			S=Math.sqrt(S);
			
			double B=0;
			for(int ran=0;ran<10000;ran++){
				double ranS=0;
				Collections.shuffle(ranpvalue);
				for(int i=0;i<set.size();i++){
					ranS=ranS+Math.abs(Double.parseDouble(ranpvalue.get(loc.get(i)))-0.5)*Math.abs(Double.parseDouble(ranpvalue.get(loc.get(i)))-0.5)/set.size();
				}
				ranS=Math.sqrt(ranS);
				if(ranS>=S){
					B=B+1;
				}
			}		
			gsea[mol][1]=Double.toString(B/10000);
			
			//gsea[mol][1]=Double.toString(S);
			set.clear();
			loc.clear();
		}
		/*************************************************************/
		try{
			outXml2 = new BufferedWriter(new FileWriter("DE_analysis_sample/DE_analysis_result.txt"));
			outXml2.write("Module ID"+"\t"+"DC p-value");
			outXml2.newLine();
			for(int t=0;t<gsea.length;t++){
				for(int j=0;j<gsea[0].length;j++){
						outXml2.write(gsea[t][j]);
						outXml2.write("\t");
			
				}
					outXml2.newLine();
			}
			outXml2.flush(); 
			outXml2.close(); 
			System.out.println("DONE"); 
		}catch (Exception e) { 
			System.out.println("FALSE"); 
		e.printStackTrace(); 
		 }
		
	}

}
