package dcde;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;



public class DC_analysis {
	private BufferedWriter outXml;
	public static void main(String[] args) {
		new DC_analysis();	
	}
	public DC_analysis(){
		int row=922;
		int colume17548=30;
		int colume57957=78;
		String cor17548[][] = new String[row][colume17548];
		String cor57957[][] = new String[row][colume57957];
		List<String> color = new ArrayList<String>();
		try {
			BufferedReader bufferedReader1 = new BufferedReader(new FileReader("DC_analysis_sample/GSE17548_modules.txt"));
			BufferedReader bufferedReader2 = new BufferedReader(new FileReader("DC_analysis_sample/GSE57957_modules.txt"));
			String lineTxt = null;
			 /****************************���ļ�******************************/
			int count1=0;
	        while((lineTxt = bufferedReader1.readLine()) != null){  
	        	//System.out.println(lineTxt); 
	    	    for(int i=0;i<Arrays.asList(lineTxt.split("\\t")).size();i++)
	    	    {
	    	    	if(count1 != 0){
	    	    		cor17548[count1-1][i]=Arrays.asList(lineTxt.split("\\t")).get(i);
		    	    	//System.out.println(value[count2][i]);
	    	    	}
	    	    }
	        	count1++;
	        }
	        bufferedReader1.close();
	        
	    int count2=0;      
        while((lineTxt = bufferedReader2.readLine()) != null){  
        	//System.out.println(lineTxt); 
    	    for(int i=0;i<Arrays.asList(lineTxt.split("\\t")).size();i++)
    	    {
    	    	if(count2 != 0){
    	    		cor57957[count2-1][i]=Arrays.asList(lineTxt.split("\\t")).get(i);
        	    	//System.out.println(value[count2][i]);
    	    	}
    	    }
        	count2++;
        }
        bufferedReader2.close();
    	
		}catch (Exception e) {
	        System.out.println("��ȡ�ļ����ݳ���");
	        e.printStackTrace();
	    }
		/***************************���ļ�*******************************/
		/**************************�õ�����ģ����ɫ�б�********************************/
        HashSet<String> mol = new HashSet<String>();
        
        for(int i=0;i<cor17548.length;i++){
        	if(cor17548[i][1] != null && cor17548[i][1].length() > 0){
        		mol.add(cor17548[i][1]);
        	}    	
        }
        Iterator<String> iterator=mol.iterator();
    	while(iterator.hasNext()){
			color.add(iterator.next());
		}
    	/**************************�õ�����ģ����ɫ�б�********************************/
    	String cocluster[][] = new String[color.size()][3];
    
	    /*************************************����ѭ��**************************************/
    	for(int i=0;i<color.size();i++){
    		cocluster[i][0]=color.get(i);
    		List<Integer> gene = new ArrayList<Integer>();
			for(int j=0;j<cor17548.length;j++){
				if(cor17548[j][1].equals(color.get(i))){
					gene.add(j);
				}
			}
			int nc=gene.size();
			String M17548[][] = new String[nc][colume17548-2];
			String M57957[][] = new String[nc][colume57957-2];

			for(int m=0;m<nc;m++){
				for(int n=0;n<M17548[0].length;n++){
				M17548[m][n]=cor17548[gene.get(m)][n+2];
				}
			}
			for(int m=0;m<nc;m++){
				for(int n=0;n<M57957[0].length;n++){
				M57957[m][n]=cor57957[gene.get(m)][n+2];
				}
			}
			/***************************************************************************/
			
			/***************************************************************************/
			double DS=0;
			double DS1=0;
			double DS2=0;
			List<Double> DS17548 = new ArrayList<Double>();
			List<Double> DS57957 = new ArrayList<Double>();
			Pearson3 pearson = new Pearson3();
			DS17548=pearson.pearson3(M17548,14,14);
			DS57957=pearson.pearson3(M57957,37,39);
			List<Integer> list = new ArrayList<Integer>();
			for(int m=0;m<DS17548.size();m++){
				list.add(m);
			}
			double pc=nc*(nc-1)/2; //list.size()=2*pc
			for(int m=0;m<list.size()/2;m++){
				DS=DS+(DS17548.get(list.get(m+list.size()/2))-DS17548.get(list.get(m)))*(DS17548.get(list.get(m+list.size()/2))-DS17548.get(list.get(m)))/pc+(DS57957.get(list.get(m+list.size()/2))-DS57957.get(list.get(m)))*(DS57957.get(list.get(m+list.size()/2))-DS57957.get(list.get(m)))/pc;
				}
			DS=Math.sqrt(DS);
			cocluster[i][1]=Double.toString(DS);
			/*************************************�û�����****************************************/
			double b=0;	
			for(int random=0;random<10000;random++){
				double ranDS=0;
				Collections.shuffle(list);
				
				for(int m=0;m<list.size()/2;m++){
					ranDS=ranDS+(DS17548.get(list.get(m+list.size()/2))-DS17548.get(list.get(m)))*(DS17548.get(list.get(m+list.size()/2))-DS17548.get(list.get(m)))/pc+(DS57957.get(list.get(m+list.size()/2))-DS57957.get(list.get(m)))*(DS57957.get(list.get(m+list.size()/2))-DS57957.get(list.get(m)))/pc;	
				}
				ranDS=Math.sqrt(ranDS);
				/***********************************************************************/
				if(ranDS>=DS){
					b++;
				}
			}
			cocluster[i][2]=Double.toString((1+b)/10000);
    	}
    	try{
			outXml = new BufferedWriter(new FileWriter("DC_analysis_sample/DC_analysis_result.txt"));
			outXml.write("Module ID"+"\t"+"DC p-value"+"\t"+"DC q-value");
			outXml.newLine();
			for(int t=0;t<cocluster.length;t++){
				for(int j=0;j<cocluster[0].length;j++){
					if(cocluster[t][j] != null && cocluster[t][j].length() > 0){
						outXml.write(cocluster[t][j]);
						outXml.write("\t");
					}else{
						outXml.write("null");
						outXml.write("\t");
					}
			
				}
					outXml.newLine();
			}
			outXml.flush(); 
			System.out.println("DONE"); 
		}catch (Exception e) { 
			System.out.println("FALSE"); 
		e.printStackTrace(); 
		 }

	}

}

